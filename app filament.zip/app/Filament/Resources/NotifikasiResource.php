<?php

namespace App\Filament\Resources;

use App\Filament\Resources\NotifikasiResource\Pages;
use App\Models\Notifikasi;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
 // Tambahkan import Resource tujuan di bagian atas file
use App\Filament\Resources\UmkmResource;
use App\Filament\Resources\UmkmDesignResource; // Ganti dengan nama resource design kamu

class NotifikasiResource extends Resource
{
    protected static ?string $model = Notifikasi::class;

    protected static ?string $navigationIcon = 'heroicon-o-bell';

    protected static ?string $navigationLabel = 'Notifikasi';
    protected static ?string $label = 'Notifikasi';
    protected static ?string $pluralLabel = 'Notifikasi';

    protected static ?string $navigationGroup = 'System';
    
    // Badge notifikasi
public static function getNavigationBadge(): ?string
{
    $user = auth()->user();
    
    // Hitung notifikasi yang ID-nya TIDAK ada di tabel notifikasi_user untuk user ini
    $unreadCount = Notifikasi::whereDoesntHave('users', function ($query) use ($user) {
        $query->where('user_id', $user->id);
    })->count();

    return $unreadCount > 0 ? '●' : null;
}

// Opsional: Mengubah warna badge menjadi merah atau orange
protected static ?string $navigationBadgeColor = 'danger';

    // hidden button create
    public static function canCreate(): bool
    {
        return false;
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([]);
    }

    
public static function table(Table $table): Table
{
    return $table
        ->columns([
            Tables\Columns\TextColumn::make('judul'),
            Tables\Columns\TextColumn::make('pesan'),
        ])
        ->recordUrl(function (Notifikasi $record) {
            // Logika redirect berdasarkan judul
            return match ($record->judul) {
                // Jika judulnya "UMKM Baru Masuk", pergi ke halaman list UMKM
                'UMKM Baru Masuk' => UmkmResource::getUrl('index'),
                
                // Jika judulnya "Design Baru Upload", pergi ke list Design
                'Design Baru Upload' => UmkmDesignResource::getUrl('index'),
                
                // Default jika tidak ada yang cocok (tetap di halaman notifikasi atau null)
                default => null,
            };
        });
}

    public static function getPages(): array
{
    return [
        'index' => Pages\ListNotifikasis::route('/'),
    ];
}
}